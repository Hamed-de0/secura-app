from sqlalchemy.orm import Session
from app.models.risks import RiskScenario, RiskScenarioCategory
from app.models.assets import AssetTag
from app.models.risks.impact_rating import ImpactRating
from app.models.controls.control_risk_link import ControlRiskLink
from app.schemas.risks import RiskScenarioCreate, RiskScenarioUpdate
from typing import List, Optional

def create_risk_scenario(db: Session, data: RiskScenarioCreate) -> RiskScenario:
    scenario = RiskScenario(
        title_en=data.title_en,
        title_de=data.title_de,
        description_en=data.description_en,
        description_de=data.description_de,
        likelihood=data.likelihood,
        threat_id=data.threat_id,
        vulnerability_id=data.vulnerability_id,
        asset_id=data.asset_id,
        asset_group_id=data.asset_group_id,
        lifecycle_states=data.lifecycle_states,
        subcategory_id=data.subcategory_id
    )

    # Link tags
    if data.tag_ids:
        tags = db.query(AssetTag).filter(AssetTag.id.in_(data.tag_ids)).all()
        scenario.tags = tags

    db.add(scenario)
    db.commit()
    db.refresh(scenario)
    return scenario

def update_risk_scenario(db: Session, scenario_id: int, scenario_update: RiskScenarioUpdate):
    db_item = get_risk_scenario(db, scenario_id)
    if not db_item:
        return None
    update_data = scenario_update.dict(exclude_unset=True)
    for key, value in update_data.items():
        setattr(db_item, key, value)
    db.commit()
    db.refresh(db_item)
    return db_item

def get_risk_scenario(db: Session, scenario_id: int) -> Optional[RiskScenario]:
    return db.query(RiskScenario).filter(RiskScenario.id == scenario_id).first()

def get_risk_scenarios(db: Session, skip: int = 0, limit: int = 100) -> List[RiskScenario]:
    return db.query(RiskScenario).offset(skip).limit(limit).all()

def delete_risk_scenario(db: Session, scenario_id: int):
    db_item = get_risk_scenario(db, scenario_id)
    if not db_item:
        return None
    db.delete(db_item)
    db.commit()
    return db_item

def get_grouped_risk_scenarios(db: Session) -> List[dict]:
    categories = db.query(RiskScenarioCategory).all()
    result = []

    for category in categories:
        category_data = {
            "category_id": category.id,
            "category_name": category.name,
            "subcategories": []
        }

        for sub in category.subcategories:
            scenarios = db.query(RiskScenario).filter(
                RiskScenario.subcategory_id == sub.id
            ).all()

            sub_data = {
                "subcategory_id": sub.id,
                "subcategory_name": sub.name,
                "scenarios": [
                    {
                        "id": s.id,
                        "title_en": s.title_en,
                        "asset": {"id": s.asset.id, "name": s.asset.name} if s.asset else None,
                        "asset_group": {"id": s.group.id, "name": s.group.name} if s.group else None,
                        "asset_type": {"id": s.asset_type.id, "name": s.asset_type.name} if s.asset_type else None,
                        "threat": {"id": s.threat.id, "name": s.threat.name} if s.threat else None,
                        "vulnerability": {"id": s.vulnerability.id, "name": s.vulnerability.name} if s.vulnerability else None,
                        "likelihood": s.likelihood,
                        "lifecycle_states": s.lifecycle_states,
                        "status": "Open"  # You can later make this dynamic
                    }
                    for s in scenarios
                ]
            }

            category_data["subcategories"].append(sub_data)

        result.append(category_data)

    return result