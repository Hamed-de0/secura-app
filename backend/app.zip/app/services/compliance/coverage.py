# =============================================================
# 3) app/services/compliance/coverage.py
# =============================================================
from typing import Dict, List, Optional, Tuple
from sqlalchemy.orm import Session
from math import isfinite

from app.constants.compliance import (
    RELATION_WEIGHT, COVERAGE_LEVEL_WEIGHT, INHERITANCE_MULTIPLIER,
    STATUS_BOOST, MAX_ATOM_SCORE,
)
from app.services.controls.effective_overlay import get_effective_controls
from app.schemas.compliance.coverage import (
    ControlContribution, AtomCoverage, RequirementCoverage, FrameworkCoverage,
)

# ==== MODELS (adjust imports) ====
# Framework
from app.models.compliance.framework import Framework
from app.models.compliance.framework_version import FrameworkVersion
from app.models.compliance.framework_requirement import FrameworkRequirement

# Obligation atoms & mappings
from app.models.compliance.obligation_atom import ObligationAtom
from app.models.compliance.obligation_control_mapping import ObligationControlMapping

# Optional: requirement-level mappings fallback (if you also map at article level)
try:
    from app.models.compliance.requirement_control_mapping import RequirementControlMapping
except Exception:
    RequirementControlMapping = None


def _safe_div(num: float, den: float) -> float:
    if not den:
        return 0.0
    x = num / den
    return x if isfinite(x) else 0.0


def _score_atom(effective_by_ctrl: Dict[int, dict], mappings: List[ObligationControlMapping]) -> Tuple[float, List[ControlContribution]]:
    total = 0.0
    contribs: List[ControlContribution] = []

    for m in mappings:
        ctrl_id = m.control_id
        eff = effective_by_ctrl.get(ctrl_id)
        if not eff:
            continue  # control not effective at this scope

        base = RELATION_WEIGHT.get(m.relation_type, 0.0)
        level = COVERAGE_LEVEL_WEIGHT.get(getattr(m, "coverage_level", None), 1.0)
        inherit = INHERITANCE_MULTIPLIER.get(eff.get("inheritance_type"), 1.0)
        boost = STATUS_BOOST.get(eff.get("assurance_status"), 0.0)

        part = base * level * inherit
        part = min(MAX_ATOM_SCORE, max(0.0, part))
        part = min(MAX_ATOM_SCORE, part + boost)  # add small bonus; cap at 1.0

        if part <= 0:
            continue

        total += part
        contribs.append(ControlContribution(
            control_id=ctrl_id,
            source=eff["source"],
            assurance_status=eff["assurance_status"],
            relation_type=m.relation_type,
            coverage_level=getattr(m, "coverage_level", None),
            contribution=round(part, 4),
        ))

    # Cap atom score at 1.0 even if multiple controls contribute
    total = min(MAX_ATOM_SCORE, total)
    return total, contribs


def coverage_for_requirement(db: Session, scope_type: str, scope_id: int, requirement_id: int) -> RequirementCoverage:
    # Effective controls map: control_id -> {source, assurance_status, inheritance_type}
    effective = get_effective_controls(db, scope_type, scope_id)
    effective_by_ctrl = {
        e.control_id: {
            "source": e.source,
            "assurance_status": e.assurance_status,
            "inheritance_type": e.inheritance_type,
        }
        for e in effective
    }

    req: FrameworkRequirement = db.query(FrameworkRequirement).get(requirement_id)
    if not req:
        raise ValueError("Requirement not found")

    # Pull atoms under this requirement
    atoms: List[ObligationAtom] = (
        db.query(ObligationAtom)
        .filter(ObligationAtom.requirement_id == requirement_id)
        .order_by(ObligationAtom.id.asc())
        .all()
    )

    atom_coverages: List[AtomCoverage] = []
    if atoms:
        total_weight = sum(a.weight or 100 for a in atoms)
        weighted_sum = 0.0

        for a in atoms:
            maps: List[ObligationControlMapping] = (
                db.query(ObligationControlMapping)
                .filter(ObligationControlMapping.obligation_atom_id == a.id)
                .all()
            )
            atom_score, contributors = _score_atom(effective_by_ctrl, maps)
            atom_coverages.append(
                AtomCoverage(
                    atom_id=a.id,
                    atom_key=a.key,
                    title=a.title,
                    weight=a.weight or 100,
                    score=round(atom_score, 4),
                    contributors=contributors,
                )
            )
            weighted_sum += atom_score * (a.weight or 100)

        req_score = _safe_div(weighted_sum, total_weight)
    else:
        # Fallback: requirement-level mappings (if you support them)
        req_maps: List = []
        if RequirementControlMapping is not None:
            req_maps = db.query(RequirementControlMapping).filter(RequirementControlMapping.requirement_id == requirement_id).all()
        # synthesize a single pseudo-atom to reuse scoring
        class PseudoMap:
            def __init__(self, control_id, relation_type, coverage_level=None):
                self.control_id = control_id
                self.relation_type = relation_type
                self.coverage_level = coverage_level
        maps = [PseudoMap(m.control_id, m.relation_type, getattr(m, "coverage_level", None)) for m in req_maps]
        atom_score, contributors = _score_atom(effective_by_ctrl, maps)
        atom_coverages = [AtomCoverage(atom_id=0, atom_key=None, title=None, weight=100, score=round(atom_score, 4), contributors=contributors)]
        req_score = atom_score

    return RequirementCoverage(
        requirement_id=req.id,
        code=req.code,
        title=req.title,
        score=round(req_score, 4),
        atoms=atom_coverages,
    )


def coverage_for_framework_version(db: Session, scope_type: str, scope_id: int, framework_code: str, version_code: str) -> FrameworkCoverage:
    fw: Framework = db.query(Framework).filter(Framework.code == framework_code).first()
    if not fw:
        raise ValueError("Framework not found")
    ver: FrameworkVersion = (
        db.query(FrameworkVersion)
        .filter(FrameworkVersion.framework_id == fw.id, FrameworkVersion.code == version_code)
        .first()
    )
    if not ver:
        raise ValueError("Framework version not found")

    reqs: List[FrameworkRequirement] = (
        db.query(FrameworkRequirement)
        .filter(FrameworkRequirement.framework_version_id == ver.id)
        .order_by(FrameworkRequirement.sort_order.asc(), FrameworkRequirement.id.asc())
        .all()
    )

    covers: List[RequirementCoverage] = []
    total = 0.0
    for r in reqs:
        rc = coverage_for_requirement(db, scope_type, scope_id, r.id)
        covers.append(rc)
        total += rc.score

    framework_score = _safe_div(total, len(reqs) or 1)
    return FrameworkCoverage(
        framework=fw.code,
        version=ver.code,
        score=round(framework_score, 4),
        requirements=covers,
    )

