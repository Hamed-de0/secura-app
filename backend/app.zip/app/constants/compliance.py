# =============================================================
# GOAL (short):
# -------------------------------------------------------------
# Compute compliance coverage for a framework/version (e.g., GDPR)
# at a reporting scope by rolling up obligation ATOM coverage derived
# from the EFFECTIVE controls overlay you just implemented.
#
# Files:
#  1) app/constants/compliance.py                  (weights/tuning)
#  2) app/schemas/compliance/coverage.py           (response models)
#  3) app/services/compliance/coverage.py          (core logic)
#  4) app/api/compliance/coverage.py               (GET endpoints)
#
# NOTE: Adjust model import paths to match your tree.
# =============================================================

# =============================================================
# 1) app/constants/compliance.py
# =============================================================
RELATION_WEIGHT = {
    "satisfies": 1.0,
    "supports": 0.4,
    "enables": 0.2,
}
COVERAGE_LEVEL_WEIGHT = {
    "full": 1.0,
    "partial": 0.6,
    "conditional": 0.5,
}
INHERITANCE_MULTIPLIER = {  # from provider services
    "direct": 1.0,
    "conditional": 0.5,
    "advisory": 0.0,
    None: 1.0,
}
STATUS_BOOST = {
    "fresh": 0.10,
    "evidenced": 0.05,
    # others = 0
}
MAX_ATOM_SCORE = 1.0