

# =============================================================
# 4) app/api/compliance/coverage.py
# =============================================================
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from typing import Optional

from app.database import get_db
from app.constants.scopes import is_valid_scope, normalize_scope
from app.schemas.compliance.coverage import FrameworkCoverage, RequirementCoverage
from app.services.compliance.coverage import coverage_for_framework_version, coverage_for_requirement

router = APIRouter(prefix="/compliance", tags=["Compliance – Coverage"])

@router.get("/coverage", response_model=FrameworkCoverage)
def get_framework_coverage(
    framework: str = Query(..., example="GDPR"),
    version: str = Query(..., example="EU 2016/679"),
    scope_type: str = Query(..., example="entity"),
    scope_id: int = Query(..., example=1),
    db: Session = Depends(get_db),
):
    if not is_valid_scope(scope_type):
        raise HTTPException(400, detail=f"Unsupported scope_type '{scope_type}'")
    try:
        return coverage_for_framework_version(db, normalize_scope(scope_type), scope_id, framework, version)
    except ValueError as e:
        raise HTTPException(404, detail=str(e))


@router.get("/requirements/{requirement_id}/coverage", response_model=RequirementCoverage)
def get_requirement_coverage(
    requirement_id: int,
    scope_type: str = Query(..., example="entity"),
    scope_id: int = Query(..., example=1),
    db: Session = Depends(get_db),
):
    if not is_valid_scope(scope_type):
        raise HTTPException(400, detail=f"Unsupported scope_type '{scope_type}'")
    try:
        return coverage_for_requirement(db, normalize_scope(scope_type), scope_id, requirement_id)
    except ValueError as e:
        raise HTTPException(404, detail=str(e))

# Register this router in your main api router:
# api_router.include_router(router)
