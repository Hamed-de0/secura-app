import * as React from "react";
import { apiLogin, apiMe } from "../api/services/auth";

const AuthCtx = React.createContext(null);

export function AuthProvider({ children }) {
  const [token, setToken] = React.useState(() => localStorage.getItem("auth_token") || "");
  const [profile, setProfile] = React.useState(null); // { user, person, permissions }

  const loadMe = React.useCallback(async () => {
    if (!localStorage.getItem("auth_token")) { setProfile(null); return null; }
    try {
      const res = await apiMe();
      setProfile(res);
      return res;
    } catch {
      // token invalid/expired
      localStorage.removeItem("auth_token");
      setToken("");
      setProfile(null);
      return null;
    }
  }, []);

  React.useEffect(() => { loadMe(); }, [loadMe]);

  const login = React.useCallback(async ({ identifier, password }) => {
    const { access_token } = await apiLogin({ identifier, password });
    localStorage.setItem("auth_token", access_token);
    setToken(access_token);
    const res = await loadMe();
    return res;
  }, [loadMe]);

  const logout = React.useCallback(() => {
    localStorage.removeItem("auth_token");
    setToken("");
    setProfile(null);
  }, []);

  const value = React.useMemo(() => ({
    token, profile, login, logout, reloadMe: loadMe,
    displayName:
      profile?.person?.display_name
      || profile?.user?.name
      || profile?.user?.user_name
      || profile?.user?.email
      || "",
  }), [token, profile, login, logout, loadMe]);

  return <AuthCtx.Provider value={value}>{children}</AuthCtx.Provider>;
}

export function useAuth() {
  const ctx = React.useContext(AuthCtx);
  if (!ctx) throw new Error("useAuth must be used within <AuthProvider/>");
  return ctx;
}
