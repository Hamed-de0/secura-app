export const sampleVendors = [
  { id:'v-1001', name:'Acme Cloud', tier:'critical', owner:'cloud@company.com', status:'active', nextReview:'2025-11-01', questionnaires:['SIG','CAIQ'] },
  { id:'v-1002', name:'MailFast', tier:'high', owner:'it@company.com', status:'active', nextReview:'2025-09-25', questionnaires:['SIG'] },
  { id:'v-1003', name:'LogOps', tier:'medium', owner:'secops@company.com', status:'pending', nextReview:'2025-10-15', questionnaires:[] },
];
