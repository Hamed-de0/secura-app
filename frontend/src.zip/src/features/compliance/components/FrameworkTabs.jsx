import * as React from "react";
import { Box, Chip, Stack, Skeleton, Tooltip } from "@mui/material";
import { useComplianceStatic } from "../../../store/complianceStaticStore";
import { ScopeContext } from "../../../store/scope/ScopeProvider";
import { fetchActiveFrameworks } from "../../../api/services/compliance";
import { adaptActivations, buildFrameworkPills } from "../../../api/adapters/compliance";

export default function FrameworkTabs() {
  const { frameworks, loaded: staticLoaded } = useComplianceStatic();
  const { scope, versionId, setVersionId } = React.useContext(ScopeContext);

  const [byVersion, setByVersion] = React.useState(new Map());
  const [loading, setLoading] = React.useState(false);

  // Load activations when scope changes
  React.useEffect(() => {
    let mounted = true;
    (async () => {
      if (!scope?.type || !scope?.id) return;
      setLoading(true);
      try {
        const resp = await fetchActiveFrameworks({ scopeType: scope.type, scopeId: scope.id });
        if (!mounted) return;
        const { byVersion: map } = adaptActivations(resp);
        setByVersion(map);
      } catch (e) {
        console.error(e);
        if (mounted) setByVersion(new Map());
      } finally {
        if (mounted) setLoading(false);
      }
    })();
    return () => { mounted = false; };
  }, [scope?.type, scope?.id]);

  // If current versionId is missing in list, auto-pick first active or first item (only on first ready)
  const bootstrappedRef = React.useRef(false);
  React.useEffect(() => {
    if (!staticLoaded || !frameworks?.length) return;
    if (bootstrappedRef.current) return;
    bootstrappedRef.current = true;

    const exists = frameworks.some(f => f.versionId === Number(versionId));
    if (exists) return;

    const firstActive = frameworks.find(f => byVersion.has(f.versionId));
    setVersionId(firstActive?.versionId ?? frameworks[0].versionId);
  }, [staticLoaded, frameworks, byVersion, versionId, setVersionId]);

  const pills = React.useMemo(
    () => buildFrameworkPills(frameworks || [], byVersion, Number(versionId)),
    [frameworks, byVersion, versionId]
  );

  if (!staticLoaded) {
    return (
      <Stack direction="row" spacing={1} sx={{ px: 1, py: 0.5, overflowX: "auto" }}>
        {Array.from({ length: 5 }).map((_, i) => <Skeleton key={i} variant="rounded" width={120} height={32} />)}
      </Stack>
    );
  }

  return (
    <Box sx={{ px: 1, py: 0.5, overflowX: "auto" }}>
      <Stack direction="row" spacing={1} sx={{ minHeight: 36 }}>
        {pills.map(p => {
          const color = p.isActiveAtScope ? "primary" : "default";
          const variant = p.selected ? "filled" : "outlined";
          const label = p.label; // "ISO/IEC 27001 2022", etc.

          const chip = (
            <Chip
              key={p.versionId}
              label={label}
              variant={variant}
              color={color}
              clickable
              onClick={() => setVersionId(p.versionId)}
              sx={{ height: 32 }}
            />
          );

          return p.isActiveNow
            ? <Tooltip key={p.versionId} title="Active at this scope now">{chip}</Tooltip>
            : chip;
        })}

        {loading && <Skeleton variant="rounded" width={90} height={32} />}
      </Stack>
    </Box>
  );
}
