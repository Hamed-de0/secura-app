export const sampleSoA = [
  { id:'A.5.1', title:'Policies for information security', included:true, rationale:'Mandatory policy', control:'AC-01' },
  { id:'A.8.3', title:'Media handling', included:false, rationale:'Out of scope for product-only org', control:null },
  { id:'A.12.4', title:'Logging and monitoring', included:true, rationale:'Risk-based requirement', control:'AU-12' },
];
