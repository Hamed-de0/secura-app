const config = {
  API_BASE_URL: "http://127.0.0.1:8001", 
};

export default config;