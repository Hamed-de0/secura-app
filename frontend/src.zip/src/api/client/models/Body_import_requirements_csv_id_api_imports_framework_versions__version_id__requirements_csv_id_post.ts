/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type Body_import_requirements_csv_id_api_imports_framework_versions__version_id__requirements_csv_id_post = {
    file: Blob;
};

