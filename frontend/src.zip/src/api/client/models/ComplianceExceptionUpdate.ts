/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type ComplianceExceptionUpdate = {
    title?: (string | null);
    description?: (string | null);
    reason?: (string | null);
    risk_acceptance_ref?: (string | null);
    compensating_controls?: (string | null);
    requested_by?: (string | null);
    owner?: (string | null);
    start_date?: (string | null);
    end_date?: (string | null);
    control_id?: (number | null);
    framework_requirement_id?: (number | null);
};

