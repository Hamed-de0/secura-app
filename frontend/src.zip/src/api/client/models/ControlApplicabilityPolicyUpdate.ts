/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type ControlApplicabilityPolicyUpdate = {
    set_type?: (string | null);
    asset_type_id?: (number | null);
    asset_tag_id?: (number | null);
    asset_group_id?: (number | null);
    controls_json?: (Array<number> | null);
    priority?: (number | null);
    effective_from?: (string | null);
    effective_to?: (string | null);
    notes?: (string | null);
};

