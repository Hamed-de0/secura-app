/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type ControlContextEffectOverrideCreate = {
    risk_scenario_context_id: number;
    control_id: number;
    domain_id: number;
    score_override: number;
    last_tested_at?: (string | null);
};

