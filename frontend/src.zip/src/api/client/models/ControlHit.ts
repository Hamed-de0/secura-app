/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type ControlHit = {
    control_id: number;
    source: string;
    assurance_status: string;
    inheritance_type?: (string | null);
    weight_share: number;
    contribution: number;
};

