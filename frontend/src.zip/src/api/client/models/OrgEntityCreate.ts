/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type OrgEntityCreate = {
    group_id?: (number | null);
    code: string;
    name: string;
    is_active?: boolean;
    regulatory_profile?: Record<string, any>;
    meta?: Record<string, any>;
};

