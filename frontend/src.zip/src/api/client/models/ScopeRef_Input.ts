/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type ScopeRef_Input = {
    type: ScopeRef_Input.type;
    id: number;
};
export namespace ScopeRef_Input {
    export enum type {
        ASSET = 'asset',
        ASSET_TYPE = 'asset_type',
        ASSET_GROUP = 'asset_group',
        ASSET_TAG = 'asset_tag',
        BU = 'bu',
        SITE = 'site',
        ENTITY = 'entity',
        SERVICE = 'service',
        ORG_GROUP = 'org_group',
    }
}

