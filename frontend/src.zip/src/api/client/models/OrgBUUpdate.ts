/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type OrgBUUpdate = {
    code?: (string | null);
    name?: (string | null);
    is_active?: (boolean | null);
    regulatory_profile?: (Record<string, any> | null);
    meta?: (Record<string, any> | null);
};

