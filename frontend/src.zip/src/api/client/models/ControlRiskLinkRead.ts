/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type ControlRiskLinkRead = {
    control_id: number;
    risk_scenario_id: number;
    status?: (string | null);
    justification?: (string | null);
    residual_score?: (number | null);
    effect_type?: (string | null);
    id: number;
};

