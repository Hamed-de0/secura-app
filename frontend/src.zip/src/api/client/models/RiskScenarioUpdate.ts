/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type RiskScenarioUpdate = {
    title_en?: (string | null);
    title_de?: (string | null);
    description_en?: (string | null);
    description_de?: (string | null);
    status?: (string | null);
    likelihood?: (number | null);
    impact?: (Record<string, any> | null);
};

