/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type RiskScenarioCategoryCreate = {
    name_en: string;
    name_de?: (string | null);
    description_en?: (string | null);
    description_de?: (string | null);
};

