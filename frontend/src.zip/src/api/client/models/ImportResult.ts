/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type ImportResult = {
    framework_version_id: number;
    total_rows: number;
    created: number;
    updated: number;
    linked_parents: number;
    dry_run: boolean;
    skipped?: number;
    errors?: Array<string>;
};

