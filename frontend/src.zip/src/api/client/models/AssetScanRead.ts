/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type AssetScanRead = {
    asset_id: number;
    scanner: string;
    status: (string | null);
    scan_date: (string | null);
    vulns_found: (number | null);
    report_url: (string | null);
    description: (string | null);
    id: number;
};

