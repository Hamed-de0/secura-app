/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type AssetSecurityProfileRead = {
    asset_id: number;
    confidentiality: (number | null);
    integrity: (number | null);
    availability: (number | null);
    classification: (string | null);
    description: (string | null);
    id: number;
};

