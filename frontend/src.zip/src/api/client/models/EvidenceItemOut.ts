/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type EvidenceItemOut = {
    id: number;
    contextId: number;
    controlId?: (number | null);
    linkId: number;
    type: string;
    ref?: (string | null);
    capturedAt?: (string | null);
    validUntil?: (string | null);
    freshness: string;
};

