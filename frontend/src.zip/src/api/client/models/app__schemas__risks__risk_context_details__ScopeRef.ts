/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type app__schemas__risks__risk_context_details__ScopeRef = {
    type?: (string | null);
    id?: (number | null);
    label?: (string | null);
};

