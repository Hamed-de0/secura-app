/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type FrameworkOut = {
    name: string;
    owner?: (string | null);
    notes?: (string | null);
    id: number;
};

