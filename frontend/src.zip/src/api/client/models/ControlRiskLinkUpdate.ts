/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type ControlRiskLinkUpdate = {
    status?: (string | null);
    justification?: (string | null);
    residual_score?: (number | null);
    effect_type?: (string | null);
};

