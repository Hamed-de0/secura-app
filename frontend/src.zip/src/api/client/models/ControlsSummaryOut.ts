/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type ControlsSummaryOut = {
    countsByStatus: Record<string, number>;
    coverageWeighted?: (number | null);
    lastEvidenceMax?: (string | null);
};

