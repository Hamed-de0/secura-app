/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type ControlFrameworkMappingUpdate = {
    obligation_atom_id?: (number | null);
    relation_type?: (string | null);
    coverage_level?: (string | null);
    applicability?: (Record<string, any> | null);
    evidence_hint?: (Array<string> | null);
    rationale?: (string | null);
    weight?: (number | null);
    notes?: (string | null);
};

