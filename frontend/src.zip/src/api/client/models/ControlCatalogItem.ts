/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type ControlCatalogItem = {
    id: number;
    code?: (string | null);
    title?: (string | null);
};

