/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type ComplianceExceptionCommentOut = {
    id: number;
    exception_id: number;
    author: string;
    body: string;
    created_at: string;
};

