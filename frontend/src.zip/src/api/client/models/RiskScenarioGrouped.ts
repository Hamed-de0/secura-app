/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { RiskScenarioSubcategoryGrouped } from './RiskScenarioSubcategoryGrouped';
export type RiskScenarioGrouped = {
    category_id: number;
    category_name_de: string;
    category_name_en: string;
    subcategories: Array<RiskScenarioSubcategoryGrouped>;
};

