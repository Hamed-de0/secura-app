/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type Body_import_crosswalks_crosswalks_bulk_post = {
    file: Blob;
};

