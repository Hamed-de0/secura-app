/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type AssetOwnerCreate = {
    asset_id: number;
    person_id: number;
    role: (string | null);
    valid_from: (string | null);
    valid_to: (string | null);
    description: (string | null);
    person_full_name: (string | null);
};

