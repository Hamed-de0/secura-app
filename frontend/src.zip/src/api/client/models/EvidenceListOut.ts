/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { EvidenceItemOut } from './EvidenceItemOut';
export type EvidenceListOut = {
    total: number;
    items: Array<EvidenceItemOut>;
    summary: Record<string, number>;
};

