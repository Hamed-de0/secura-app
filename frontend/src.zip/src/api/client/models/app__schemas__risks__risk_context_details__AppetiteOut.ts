/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { SlaDaysOut } from './SlaDaysOut';
export type app__schemas__risks__risk_context_details__AppetiteOut = {
    greenMax: number;
    amberMax: number;
    domainCaps?: Record<string, number>;
    slaDays: SlaDaysOut;
};

