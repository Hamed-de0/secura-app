/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type OrgBUCreate = {
    entity_id: number;
    code: string;
    name: string;
    is_active?: boolean;
    regulatory_profile?: Record<string, any>;
    meta?: Record<string, any>;
};

