/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type EvidencePolicyOut = {
    id: number;
    control_id: (number | null);
    framework_requirement_id: (number | null);
    freshness_days: number;
    notes?: (string | null);
};

