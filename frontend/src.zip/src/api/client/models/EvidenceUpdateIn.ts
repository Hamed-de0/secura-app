/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type EvidenceUpdateIn = {
    type?: (string | null);
    title?: (string | null);
    ref?: (string | null);
    capturedAt?: (string | null);
    validUntil?: (string | null);
    description?: (string | null);
    status?: (string | null);
};

