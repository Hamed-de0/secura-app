/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type Body_import_crosswalks_csv_api_imports_framework_versions__version_id__crosswalks_csv_post = {
    file: Blob;
};

