/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type SlaDaysOut = {
    amber?: (number | null);
    red?: (number | null);
};

