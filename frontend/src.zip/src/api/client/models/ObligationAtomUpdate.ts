/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type ObligationAtomUpdate = {
    atom_key?: (string | null);
    role?: (string | null);
    obligation_text?: (string | null);
    condition?: (string | null);
    outcome?: (string | null);
    citation?: (string | null);
    applicability?: (Record<string, any> | null);
    evidence_hint?: (Array<string> | null);
    sort_index?: (number | null);
};

