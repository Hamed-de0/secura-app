/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type AssetMaintenanceRead = {
    asset_id: number;
    maintenance_type: string;
    performed_by: string;
    timestamp: (string | null);
    description: (string | null);
    id: number;
};

