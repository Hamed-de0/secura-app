/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type FrameworkVersionUpdate = {
    version_label?: (string | null);
    effective_from?: (string | null);
    effective_to?: (string | null);
    notes?: (string | null);
};

