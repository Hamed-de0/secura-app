/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { PrefillPair } from './PrefillPair';
export type PrefillRequest = {
    pairs: Array<PrefillPair>;
};

