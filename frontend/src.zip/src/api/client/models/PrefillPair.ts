/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { ScopeRef_Input } from './ScopeRef_Input';
export type PrefillPair = {
    scenarioId: number;
    scopeRef: ScopeRef_Input;
};

