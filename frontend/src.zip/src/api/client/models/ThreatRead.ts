/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type ThreatRead = {
    name: string;
    category?: (string | null);
    description?: (string | null);
    source?: (string | null);
    reference_code?: (string | null);
    risk_source?: (Array<string> | null);
    id: number;
    created_at: string;
    updated_at: string;
    enabled: boolean;
};

