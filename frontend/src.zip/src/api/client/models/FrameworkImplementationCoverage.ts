/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { RequirementImplementationCoverage } from './RequirementImplementationCoverage';
export type FrameworkImplementationCoverage = {
    version_id: number;
    scope_type: string;
    scope_id: number;
    score: number;
    requirements: Array<RequirementImplementationCoverage>;
};

