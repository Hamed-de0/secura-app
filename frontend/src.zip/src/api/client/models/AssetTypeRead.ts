/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type AssetTypeRead = {
    name: string;
    category?: (string | null);
    description?: (string | null);
    id: number;
    enabled: boolean;
    created_at: string;
    updated_at: string;
};

