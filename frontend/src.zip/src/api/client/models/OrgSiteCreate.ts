/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type OrgSiteCreate = {
    entity_id: number;
    code: string;
    name: string;
    is_active?: boolean;
    meta?: Record<string, any>;
};

