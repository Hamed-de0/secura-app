/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type LifecycleEventTypeRead = {
    name: string;
    description?: (string | null);
    id: number;
};

