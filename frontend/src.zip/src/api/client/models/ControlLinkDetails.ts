/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type ControlLinkDetails = {
    linkId: number;
    controlId: number;
    name: string;
    referenceCode?: (string | null);
    assuranceStatus?: (string | null);
    statusUpdatedAt?: (string | null);
    evidenceUpdatedAt?: (string | null);
    effectivenessOverride?: (Record<string, number> | null);
    notes?: (string | null);
};

