/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type PersonCreate = {
    first_name: string;
    last_name: string;
    email?: (string | null);
    department?: (string | null);
    job_title?: (string | null);
    location?: (string | null);
    phone?: (string | null);
    notes?: (string | null);
    enabled?: (boolean | null);
    display_name?: (string | null);
    initials?: (string | null);
    avatar_url?: (string | null);
    kind?: (string | null);
    external_ids?: (Record<string, any> | null);
    timezone?: (string | null);
};

