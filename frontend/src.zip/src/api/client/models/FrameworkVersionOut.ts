/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type FrameworkVersionOut = {
    id: number;
    framework_id: number;
    version_label: string;
    effective_from?: (string | null);
    effective_to?: (string | null);
    notes?: (string | null);
};

