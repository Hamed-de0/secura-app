// src/api/adapters/compliance.js

export function statusChipMeta(status, exception = false) {
  const s = String(status || '').toLowerCase();
  const color = s === 'met' ? 'success' : s === 'partial' ? 'warning' : s === 'gap' ? 'error' : 'default';
  const variant = exception ? 'outlined' : 'filled';
  return { color, variant, label: exception ? `${s}*` : s || '—' };
}

export function adaptSummaryToKpis(sum) {
  if (!sum) return {
    coveragePct: 0, coveragePctNoEx: 0,
    met: 0, partial: 0, gap: 0, unknown: 0,
    lastComputedAt: null,
  };
  return {
    coveragePct: sum.coverage_pct ?? 0,
    coveragePctNoEx: sum.coverage_pct_excl_exceptions ?? 0,
    met: sum.met ?? 0,
    partial: sum.partial ?? 0,
    gap: sum.gap ?? 0,
    unknown: sum.unknown ?? 0,
    lastComputedAt: sum.last_computed_at || null,
  };
}

export function adaptStatusItem(it) {
  // Normalize fields expected by grid + drawer
  return {
    id: it.requirement_id,
    requirement_id: it.requirement_id,
    code: it.code || String(it.requirement_id),
    title: it.title || '',
    status: it.status || 'unknown',
    score: Number(it.score ?? 0),
    exception_applied: !!it.exception_applied,
    parent_id: it.parent_id ?? null,
    top_level_id: it.top_level_id ?? null,
    top_level_code: it.top_level_code ?? null,
    breadcrumb: it.breadcrumb || null,
  };
}

export function adaptStatusPage(resp) {
  return {
    versionId: resp.version_id,
    scopeType: resp.scope_type,
    scopeId: resp.scope_id,
    page: resp.page,
    size: resp.size,
    total: resp.total,
    items: (resp.items || []).map(r => ({
      id: r.requirement_id,           // <-- DataGrid needs this
      requirement_id: r.requirement_id,
      code: r.code,
      title: r.title,
      status: r.status,
      score: r.score,
      exception_applied: r.exception_applied,
      parent_id: r.parent_id,
      top_level_id: r.top_level_id,
      top_level_code: r.top_level_code,
      breadcrumb: r.breadcrumb,
    })),
  };
}


export function pickRequirementDetailFromCoverage(fcov, requirementId) {
  const r = (fcov?.requirements || []).find(x => Number(x.requirement_id) === Number(requirementId));
  if (!r) return null;
  // Derive “gaps” = mapped but no effective hit (if backend gives only hits, leave empty array)
  const hits = r.hits || [];
  return {
    requirement_id: r.requirement_id,
    code: r.code || String(r.requirement_id),
    title: r.title || '',
    score: r.score ?? 0,
    status: r.status || 'unknown',
    exception_applied: !!r.exception_applied,
    hits,
    mapped_but_not_effective: r.mapped_but_not_effective || [],
  };
}

// append these helpers
export function adaptActivations(resp) {
  const items = resp?.items || [];
  const byVersion = new Map(
    items.map(i => [i.version_id, {
      versionId: i.version_id,
      frameworkId: i.framework_id,
      frameworkName: i.framework_name,
      versionLabel: i.version_label,
      isActiveNow: !!i.is_active_now,
      policyId: i.policy_id,
    }])
  );
  return { scopeType: resp?.scope_type, scopeId: resp?.scope_id, items, byVersion };
}

export function buildFrameworkPills(frameworks = [], byVersion = new Map(), selectedVersionId) {
  return frameworks.map(fw => {
    const act = byVersion.get(fw.versionId);
    return {
      ...fw, // {versionId, frameworkId, label, frameworkName, versionLabel}
      isActiveAtScope: !!act,
      isActiveNow: !!act?.isActiveNow,
      selected: fw.versionId === selectedVersionId,
    };
  });
}

// add this export
export function adaptCoverageRollupToHeatmap(resp, scopeTypes = []) {
  // resp: { version_id, items: [{scope_type, met, partial, gap, unknown, applicable_requirements}] }
  const byType = new Map(scopeTypes.map(s => [s.scope_type, s.title]));
  const items = Array.isArray(resp?.items) ? resp.items : [];

  return items.map(row => {
    const met     = Number(row.met ?? 0);
    const partial = Number(row.partial ?? 0);
    const gap     = Number(row.gap ?? 0);
    const unknown = Number(row.unknown ?? 0);
    const total   = met + partial + gap + unknown;

    return {
      scopeType: row.scope_type,
      title: byType.get(row.scope_type) ?? row.scope_type,
      counts: { met, partial, gap, unknown, total }
    };
  });
}

// ADD THIS
export function adaptCoverageList(resp) {
  const items = (resp?.items || []).map((r, i) => ({
    id: r.requirement_id ?? i,
    requirement_id: r.requirement_id,
    code: r.code || r.requirement_code,
    title: r.title || r.requirement_title,
    status: r.status,
    score: r.score,
    scope_type: r.scope_type,
    scope_id: r.scope_id,
  }));
  return { items, total: resp?.total ?? items.length };
}




