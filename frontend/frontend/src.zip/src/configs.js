const config = {
  API_BASE_URL: "http://localhost:8001", 
};

export default config;