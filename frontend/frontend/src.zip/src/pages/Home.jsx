import React from 'react';
const Home = () => {
  return (
    <>
      <div>Welcome to the ISMS Frontend</div>
    </>
  );
};

export default Home;
