import * as React from "react";
import {
  Box, Grid, Card, CardContent, Typography, Stack, Chip, Button, Alert, LinearProgress
} from "@mui/material";
import { DataGrid } from "@mui/x-data-grid";
import { Link as RouterLink, useSearchParams, useParams, useNavigate } from "react-router-dom";

import {
  fetchComplianceSummary,
  fetchActiveFrameworks,
  fetchStaleEvidence,
  fetchRequirementsStatusPage
} from "../../../api/services/compliance";

import { adaptSummaryToKpis, adaptStatusPage } from "../../../api/adapters/compliance";
import StatusChip from "../../../components/ui/StatusChip.jsx";
import { DEFAULT_SCOPE } from "../../../app/constants.js";

export default function ComplianceDashboard() {
  const navigate = useNavigate();
  const { versionId: routeVersion } = useParams();
  const [sp] = useSearchParams();

  // --- Resolve scope from URL or defaults
  const scopeType = sp.get("scope_type") || DEFAULT_SCOPE.scopeType || "org";
  const scopeId = Number(sp.get("scope_id") || DEFAULT_SCOPE.scopeId || 1);

  // If versionId is not provided, we’ll discover it from active frameworks
  const urlVersionId = (() => {
    const v = Number(routeVersion || sp.get("version_id"));
    return Number.isFinite(v) && v > 0 ? v : null;
  })();

  // --- UI state
  const [loading, setLoading] = React.useState(true);
  const [error, setError] = React.useState(null);

  const [resolvedVersionId, setResolvedVersionId] = React.useState(urlVersionId);
  const [kpi, setKpi] = React.useState(null);
  const [activations, setActivations] = React.useState([]);
  const [evi, setEvi] = React.useState({ expired_count: 0, expiring_soon_count: 0 });
  const [gaps, setGaps] = React.useState([]);

  // helper: derive a usable version id from activations payload
  const pickVersionId = React.useCallback((items) => {
    if (!Array.isArray(items) || items.length === 0) return null;
    const first = items[0];
    return (
      first?.version_id ??
      first?.framework_version_id ??
      first?.latest_version_id ??
      null
    );
  }, []);

  // Keep URL in sync once we resolve a version (nice to have)
  React.useEffect(() => {
    if (!resolvedVersionId) return;
    const params = new URLSearchParams(sp);
    params.set("scope_type", scopeType);
    params.set("scope_id", String(scopeId));
    params.set("version_id", String(resolvedVersionId));
    // Avoid pushing a new entry if nothing changed
    const newSearch = `?${params.toString()}`;
    if (newSearch !== `?${sp.toString()}`) {
      navigate({ search: newSearch }, { replace: true });
    }
  }, [resolvedVersionId, scopeType, scopeId]); // eslint-disable-line react-hooks/exhaustive-deps

  // Main loader: fetch activations → decide version → then load summary/evidence/gaps
  React.useEffect(() => {
    let abort = new AbortController();
    (async () => {
      try {
        setLoading(true);
        setError(null);

        // 1) Get active frameworks for scope
        const af = await fetchActiveFrameworks({ scopeType, scopeId, signal: abort.signal }).catch((e) => {
          // Not fatal for the whole page; we’ll keep going
          console.error("active frameworks error:", e);
          return { items: [] };
        });
        const items = af?.items || af || [];
        setActivations(items);

        // 2) Decide which version to use (URL wins, otherwise derive)
        let vId = urlVersionId;
        if (!vId) vId = pickVersionId(items);
        if (!vId) {
          throw new Error(
            "No framework version available for this scope. Add a framework activation policy or provide ?version_id=… in the URL."
          );
        }
        setResolvedVersionId(vId);

        // 3) Load summary (requires version_id), evidence, top gaps
        const [summary, ev, page] = await Promise.all([
          fetchComplianceSummary({ versionId: vId, scopeType, scopeId, signal: abort.signal }),
          fetchStaleEvidence({ withinDays: 30, scopeType, scopeId, page: 1, size: 5, signal: abort.signal }),
          fetchRequirementsStatusPage({
            versionId: vId,
            scopeType,
            scopeId,
            status: "gap,partial",
            sortBy: "score",
            sortDir: "asc",
            page: 1,
            size: 5,
            signal: abort.signal
          })
        ]);

        setKpi(adaptSummaryToKpis(summary));
        setEvi({
          expired_count: ev?.expired_count || 0,
          expiring_soon_count: ev?.expiring_soon_count || 0
        });
        setGaps(adaptStatusPage(page).items || []);
      } catch (e) {
        console.error(e);
        setError(e?.message || "Failed to load compliance data.");
      } finally {
        setLoading(false);
      }
    })();

    return () => {
      abort.abort();
    };
  }, [scopeType, scopeId, urlVersionId, pickVersionId]);

  const Stat = ({ label, value, hint }) => (
    <Card>
      <CardContent>
        <Typography variant="overline" color="text.secondary">{label}</Typography>
        <Typography variant="h5">{value ?? "—"}</Typography>
        {hint && <Typography variant="caption" color="text.secondary">{hint}</Typography>}
      </CardContent>
    </Card>
  );

  const gapCols = [
    { field: "code", headerName: "Code", width: 120 },
    { field: "title", headerName: "Requirement", flex: 1, minWidth: 240 },
    {
      field: "status",
      headerName: "Status",
      width: 120,
      renderCell: (p) => <StatusChip value={p.row.status} exception={p.row.exception_applied} />
    },
    {
      field: "score",
      headerName: "Score",
      width: 110,
      valueFormatter: ({ value }) => `${Math.round((value ?? 0) * 100)}%`
    }
  ];

  return (
    <Box sx={{ p: 2 }}>
      {loading && <LinearProgress sx={{ mb: 2 }} />}
      {error && (
        <Alert severity="error" sx={{ mb: 2 }}>
          {error}
        </Alert>
      )}

      {/* KPI strip */}
      <Grid container spacing={2} sx={{ mb: 1 }}>
        <Grid item xs={12} sm={4}>
          <Stat
            label="Coverage %"
            value={kpi ? `${kpi.coveragePct}%` : "—"}
            hint="Includes exceptions"
          />
        </Grid>
        <Grid item xs={12} sm={4}>
          <Stat
            label="No-exception coverage"
            value={kpi ? `${kpi.coveragePctNoEx}%` : "—"}
          />
        </Grid>
        <Grid item xs={12} sm={4}>
          <Card>
            <CardContent>
              <Typography variant="overline" color="text.secondary">Status</Typography>
              <Stack direction="row" spacing={1} sx={{ mt: 1, flexWrap: "wrap" }}>
                <Chip label={`Met ${kpi?.met ?? 0}`} color="success" size="small" />
                <Chip label={`Partial ${kpi?.partial ?? 0}`} color="warning" size="small" />
                <Chip label={`Gaps ${kpi?.gap ?? 0}`} color="error" size="small" />
                <Chip label={`Unknown ${kpi?.unknown ?? 0}`} size="small" />
              </Stack>
              <Typography variant="caption" color="text.secondary" sx={{ display: "block", mt: 1 }}>
                Last computed: {kpi?.lastComputedAt ? new Date(kpi.lastComputedAt).toLocaleString() : "—"}
              </Typography>
            </CardContent>
          </Card>
        </Grid>
      </Grid>

      {/* Activations + Evidence */}
      <Grid container spacing={2}>
        <Grid item xs={12} md={6}>
          <Card>
            <CardContent>
              <Typography variant="subtitle2" sx={{ mb: 1 }}>Active frameworks at scope</Typography>
              <Stack direction="row" spacing={1} sx={{ flexWrap: "wrap" }}>
                {activations.length === 0 ? (
                  <Typography variant="body2" color="text.secondary">None</Typography>
                ) : (
                  activations.map((a, idx) => (
                    <Chip
                      key={`${a.version_id || a.framework_version_id || a.latest_version_id || idx}-${a.policy_id || idx}`}
                      label={`${a.framework_name} ${a.version_label || ""}`.trim()}
                      color={a.is_active_now ? "primary" : "default"}
                      size="small"
                    />
                  ))
                )}
              </Stack>
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} md={6}>
          <Card>
            <CardContent>
              <Typography variant="subtitle2" sx={{ mb: 1 }}>Evidence freshness</Typography>
              <Stack direction="row" spacing={2}>
                <Chip label={`Expired: ${evi.expired_count}`} color="error" />
                <Chip label={`Expiring (30d): ${evi.expiring_soon_count}`} color="warning" />
              </Stack>
            </CardContent>
          </Card>
        </Grid>

        {/* Top gaps/partials */}
        <Grid item xs={12}>
          <Card>
            <CardContent>
              <Stack direction="row" justifyContent="space-between" alignItems="center" sx={{ mb: 1 }}>
                <Typography variant="subtitle2">Top gaps (lowest scores)</Typography>
                <Button
                  component={RouterLink}
                  to={`/compliance/versions/${resolvedVersionId || ""}?scope_type=${scopeType}&scope_id=${scopeId}`}
                  size="small"
                  variant="outlined"
                  disabled={!resolvedVersionId}
                >
                  Open Explorer
                </Button>
              </Stack>
              <Box sx={{ height: 360 }}>
                <DataGrid
                  rows={gaps}
                  columns={gapCols}
                  getRowId={(r) => r.id || `${r.code}-${r.requirement_id || r.title}`}
                  density="compact"
                  disableColumnMenu
                  hideFooterSelectedRowCount
                  pageSizeOptions={[5]}
                  initialState={{ pagination: { paginationModel: { pageSize: 5 } } }}
                />
              </Box>
            </CardContent>
          </Card>
        </Grid>
      </Grid>
    </Box>
  );
}
