// src/api/services/compliance.js
import { getJSON, buildSearchParams } from '../../api/httpClient';
import { DEFAULT_SCOPE } from '../../app/constants';

// KPI summary
export async function fetchComplianceSummary({ versionId, scopeType=DEFAULT_SCOPE.scopeType, scopeId=DEFAULT_SCOPE.scopeId }) {
  const searchParams = buildSearchParams({
    version_id: versionId,
    scope_type: scopeType,
    scope_id: scopeId,
  });
    if (!versionId) throw new Error('fetchComplianceSummary: versionId is required');
    return await getJSON('compliance/coverage/summary', { searchParams });
}

// Requirements status (paginated + filterable)
export async function fetchRequirementsStatusPage({
  versionId, scopeType=DEFAULT_SCOPE.scopeType, scopeId=DEFAULT_SCOPE.scopeId,
  q, ancestorId, status,
  sortBy = 'code', sortDir = 'asc',
  page = 1, size = 50,
}) {
  const searchParams = buildSearchParams({
    version_id: versionId,
    scope_type: scopeType,
    scope_id: scopeId,
    q, ancestor_id: ancestorId, status,
    sort_by: sortBy, sort_dir: sortDir, page, size,
  });
    if (!versionId) throw new Error('fetchComplianceStatus: versionId is required');
    return await getJSON('compliance/requirements/status', { searchParams });
}

// Requirements tree (for left panel)
export async function fetchRequirementsTree({ versionId }) {
      if (!versionId) throw new Error('fetchComplianceSummary: versionId is required');

  const searchParams = buildSearchParams({ version_id: versionId });
  return await getJSON('compliance/requirements/tree', { searchParams });
}

// Active frameworks for a scope (chips on dashboard)
export async function fetchActiveFrameworks({ scopeType=DEFAULT_SCOPE.scopeType, scopeId=DEFAULT_SCOPE.scopeId }) {
  const searchParams = buildSearchParams({ scope_type: scopeType, scope_id: scopeId });
  return await getJSON('policies/framework-activation/active-for-scope', { searchParams });
}

// Evidence: expired / expiring soon (right column widget)
export async function fetchStaleEvidence({ withinDays = 30, scopeType, scopeId, status, page = 1, size = 10 }) {
  const searchParams = buildSearchParams({
    within_days: withinDays, scope_type: scopeType, scope_id: scopeId, status, page, size,
  });
  return await getJSON('evidence/stale', { searchParams });
}

// Effective coverage (for requirement drawer – we filter to one requirement client-side)
export async function fetchEffectiveCoverage({ versionId, scopeType, scopeId }) {
  const searchParams = buildSearchParams({ scope_type: scopeType, scope_id: scopeId });
  return await getJSON(`coverage/framework_versions/${versionId}/effective`, { searchParams });
}
