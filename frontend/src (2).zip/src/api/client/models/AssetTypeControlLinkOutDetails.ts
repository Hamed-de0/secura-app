/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type AssetTypeControlLinkOutDetails = {
    id: number;
    control_id: number;
    asset_type_id: number;
    score?: (number | null);
    justification?: (string | null);
    reference_code: string;
    title_en: string;
    category: string;
    control_source: string;
    description_en?: (string | null);
};

