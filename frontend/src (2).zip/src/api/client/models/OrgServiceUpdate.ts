/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type OrgServiceUpdate = {
    provider_entity_id?: (number | null);
    provider_bu_id?: (number | null);
    code?: (string | null);
    name?: (string | null);
    service_type?: (string | null);
    is_active?: (boolean | null);
    meta?: (Record<string, any> | null);
};

