/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type OrgSiteOut = {
    entity_id: number;
    code: string;
    name: string;
    is_active?: boolean;
    meta?: Record<string, any>;
    id: number;
};

