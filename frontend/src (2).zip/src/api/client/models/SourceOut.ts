/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type SourceOut = {
    scope: string;
    name: string;
    likelihood: number;
    impacts: Record<string, number>;
};

