/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { AssetTagCreate } from './AssetTagCreate';
export type AssetTagBulkCreate = Array<AssetTagCreate>;
