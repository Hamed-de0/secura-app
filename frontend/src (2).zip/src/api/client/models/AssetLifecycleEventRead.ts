/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type AssetLifecycleEventRead = {
    asset_id: number;
    event_type: string;
    timestamp: (string | null);
    description: (string | null);
    id: number;
};

