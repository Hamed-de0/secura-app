/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type ImpactRatingIn = {
    domain_id?: (number | null);
    domain?: ('C' | 'I' | 'A' | 'L' | 'R' | null);
    score: number;
};

