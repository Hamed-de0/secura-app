/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type RiskScenarioEnrichRequest = {
    threat_id?: (string | null);
    vulnerability_id?: (string | null);
    controls?: (Array<string> | null);
};

