/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type ControlApplicabilityPolicyCreate = {
    set_type?: string;
    asset_type_id?: (number | null);
    asset_tag_id?: (number | null);
    asset_group_id?: (number | null);
    controls_json: Array<number>;
    priority?: number;
    effective_from?: (string | null);
    effective_to?: (string | null);
    notes?: (string | null);
};

