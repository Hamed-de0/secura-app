/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type ThreatUpdate = {
    name?: (string | null);
    category?: (string | null);
    description?: (string | null);
    source?: (string | null);
    reference_code?: (string | null);
    risk_source?: (Array<string> | null);
};

