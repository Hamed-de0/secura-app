/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type RiskScenarioBrief = {
    id: number;
    title_en: string;
    threat_id: (number | null);
    threat_name: (string | null);
    vulnerability_id: (number | null);
    vulnerability_name: (string | null);
    status: (string | null);
};

