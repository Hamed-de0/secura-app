/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type FrameworkRequirementUpdate = {
    code?: (string | null);
    title?: (string | null);
    text?: (string | null);
    parent_id?: (number | null);
    sort_index?: (number | null);
};

