/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type OrgSiteUpdate = {
    code?: (string | null);
    name?: (string | null);
    is_active?: (boolean | null);
    meta?: (Record<string, any> | null);
};

