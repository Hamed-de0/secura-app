/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { RiskLevelBreakdown } from './RiskLevelBreakdown';
export type DashboardSummary = {
    assets: number;
    threats: number;
    risks: number;
    controls: number;
    risk_levels: RiskLevelBreakdown;
};

