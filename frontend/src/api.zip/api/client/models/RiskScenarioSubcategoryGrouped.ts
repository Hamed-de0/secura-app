/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { RiskScenarioBrief } from './RiskScenarioBrief';
export type RiskScenarioSubcategoryGrouped = {
    subcategory_id: number;
    subcategory_name_de: string;
    subcategory_name_en: string;
    scenarios: Array<RiskScenarioBrief>;
};

