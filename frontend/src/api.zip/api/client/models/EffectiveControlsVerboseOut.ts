/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { EffectiveControlCandidate } from './EffectiveControlCandidate';
import type { EffectiveControlOut } from './EffectiveControlOut';
export type EffectiveControlsVerboseOut = {
    winners: Array<EffectiveControlOut>;
    candidates: Array<EffectiveControlCandidate>;
};

