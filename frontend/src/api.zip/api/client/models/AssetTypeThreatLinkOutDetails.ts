/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type AssetTypeThreatLinkOutDetails = {
    id: number;
    threat_id: number;
    asset_type_id: number;
    score?: (number | null);
    justification?: (string | null);
    reference_code: string;
    name: string;
    category: string;
    source: string;
    description?: (string | null);
};

