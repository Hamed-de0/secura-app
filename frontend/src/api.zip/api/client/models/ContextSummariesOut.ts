/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { ControlsSummaryOut } from './ControlsSummaryOut';
import type { EvidenceSummaryOut } from './EvidenceSummaryOut';
export type ContextSummariesOut = {
    controlsSummary: ControlsSummaryOut;
    evidenceSummary: EvidenceSummaryOut;
};

