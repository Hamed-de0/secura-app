/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type app__schemas__risks__risk_effective__EvidenceOut = {
    ok: number;
    warn: number;
    overdue: (number | null);
};

