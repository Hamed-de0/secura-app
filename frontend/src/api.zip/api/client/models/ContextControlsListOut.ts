/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { ContextControlOut } from './ContextControlOut';
import type { ContextControlsSummary } from './ContextControlsSummary';
export type ContextControlsListOut = {
    total: number;
    items: Array<ContextControlOut>;
    summary?: (ContextControlsSummary | null);
};

