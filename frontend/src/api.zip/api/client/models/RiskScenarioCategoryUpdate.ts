/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type RiskScenarioCategoryUpdate = {
    name_en?: (string | null);
    name_de?: (string | null);
    description_en?: (string | null);
    description_de?: (string | null);
};

