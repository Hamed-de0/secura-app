/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { ControlRead } from './ControlRead';
export type ControlsPage = {
    data: Array<ControlRead>;
    full_count: number;
};

