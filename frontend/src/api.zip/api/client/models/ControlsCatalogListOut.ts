/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { ControlCatalogItem } from './ControlCatalogItem';
export type ControlsCatalogListOut = {
    total: number;
    items: Array<ControlCatalogItem>;
};

