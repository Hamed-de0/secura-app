/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type AssetRelationCreate = {
    asset_id: number;
    related_asset_id: number;
    relation_type: (string | null);
    description: (string | null);
};

