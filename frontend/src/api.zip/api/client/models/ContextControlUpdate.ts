/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type ContextControlUpdate = {
    status?: ('proposed' | 'mapped' | 'planning' | 'implementing' | 'implemented' | 'monitoring' | 'analyzing' | 'evidenced' | 'fresh' | 'expired' | null);
};

