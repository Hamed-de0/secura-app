/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type EvidenceCreateIn = {
    controlId: number;
    type: string;
    title: string;
    ref?: (string | null);
    capturedAt?: (string | null);
    validUntil?: (string | null);
    description?: (string | null);
};

