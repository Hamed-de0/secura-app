/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type app__schemas__risks__risk_effective__ControlsOut = {
    implemented: number;
    total: number;
    recommended: Array<string>;
    implementedList: Array<string>;
    coverage: (number | null);
};

