import React from 'react';
import MainDashboard from '../features/dashboards/MainDashboard';

const Dashboard = () => {

  return (
    <MainDashboard/>
  );
};

export default Dashboard;
