import { Typography, Box, Button } from '@mui/material'

const Dashboard = () => (
  <Box sx={{ maxWidth: 900, margin: '2rem auto' }}>
    <Typography variant="h4" gutterBottom>
      Welcome to the ISMS Dashboard
    </Typography>
    <Typography variant="body1" paragraph>
      This is your central hub to manage assets, threats, risks, controls, and compliance.
    </Typography>
    <Button variant="contained" color="primary">
      Go to Asset Inventory
    </Button>
  </Box>
)

export default Dashboard
