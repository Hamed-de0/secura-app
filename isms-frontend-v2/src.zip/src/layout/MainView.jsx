import Header from '../components/Header'
import Sidebar from '../components/Sidebar'
import ContentView from '../components/ContentView'
import Footer from '../components/Footer'

const MainView = ({ children }) => {
  return (
    <div style={{ height: '100vh', display: 'flex', flexDirection: 'column' }}>
      <Header />
      <div style={{ display: 'flex', flex: 1, overflow: 'hidden' }}>
        <Sidebar />
        <div style={{ flex: 1, display: 'flex', flexDirection: 'column' }}>
          <ContentView>{children}</ContentView>
          <Footer />
        </div>
      </div>
    </div>
  )
}

export default MainView
