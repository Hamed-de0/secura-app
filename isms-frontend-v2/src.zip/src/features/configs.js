const config = {
  API_BASE_URL: "http://192.168.1.173:8001", 
};

export default config;

