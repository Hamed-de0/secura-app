const ContentView = ({ children }) => (
  <main style={{
    flex: 1,
    padding: '2rem',
    overflowY: 'auto',
    backgroundColor: '#f5f5f5',
  }}>
    {children}
  </main>
)

export default ContentView
