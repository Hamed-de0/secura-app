import { Box, Typography } from '@mui/material'

const Footer = () => (
  <Box sx={{ height: 48, textAlign: 'center', padding: '0.5rem', backgroundColor: '#eee' }}>
    <Typography variant="caption">© 2025 H&H Communication Lab GmbH – All rights reserved.</Typography>
  </Box>
)

export default Footer
